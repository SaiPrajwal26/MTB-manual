#ifndef APCARD_H
#define APCARD_H

#include <QMessageBox>

#include "apcards/apcommon.h"
#include "apcards/ap323.h"
#include "apcards/ap441.h"
#include "apcards/ap445.h"

class apcard
{
private:
    int optoDoCardHandle1;
    int optoDoCardHandle2;
    int optoDoCardHandle3;
    int optoDoCardHandle4;

    int optoDiCardHandle;

    int adcCardHandle1;
    int adcCardHandle2;

    //optoDo Cards//
    long baddr445_1, baddr445_2, baddr445_3, baddr445_4;    /* hold board address*/
    struct sblk445 s_block445_1, s_block445_2, s_block445_3, s_block445_4;  /* allocate status param. blk */ // structure for opto-do

    //optoDi Cards//
    long baddr441_1;    /* hold board address*/
    struct cblk441 c_block441_1;
    struct sblk441 s_block441_1;

    //ADC Cards//
    long baddr323_1,baddr323_2;
    struct cblk323 c_block323_1,c_block323_2;

    byte s_array_1[SA_SIZE];

    word raw_data_1[SA_CHANS][SA_SIZE];	/* allocate raw       data storage area */
    int  cor_data_1[SA_CHANS][SA_SIZE];	/* allocate corrected data storage area */

    byte s_array_2[SA_SIZE];

    word raw_data_2[SA_CHANS][SA_SIZE];	/* allocate raw       data storage area */
    int  cor_data_2[SA_CHANS][SA_SIZE];	/* allocate corrected data storage area */

public:
    int  open();
    void close();

    int  initDi();
    int  readDi(int ch_no);
    void closeDi();

    int initDo();
    int writeDo_1(int ch_no, int on_off);
    int readDo_1(int ch_no);
    int writeDo_2(int ch_no, int on_off);
    int readDo_2(int ch_no);
    int writeDo_3(int ch_no, int on_off);
    int readDo_3(int ch_no);
    int writeDo_4(int ch_no, int on_off);
    int readDo_4(int ch_no);

    int  writeOptoDo(int ch_no, int on_off);
    int  readOptoDoStatus(int ch_no);
    void closeDo();

    int   initAdc();

    float readADC_A(int ch_no);
    float readADC_B(int ch_no);
    void  closeAdc();

    void displayIpErrorMessage(int error);

    int   write_DO(int index,int on_off);
    float read_AI(int index);
};

#endif // APCARD_H
