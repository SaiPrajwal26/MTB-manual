#include "apcard.h"

#include <QDebug>
#define DEVICE_NAME_OPTO_DO "ap445_"      /* name of device */
#define DEVICE_NAME_OPTO_DI "ap441_"     /* name of device */
#define DEVICE_NAME_AI      "ap323_"      /* name of device */

/*
 * //-------acromag cards--------//
 *
 * ap323_0 AI Card0
 * ap323_1 AI Card1
 *
 * ap441_0 Opto-DI Card
 *
 * ap445_0 Opto-DO Card0
 * ap445_1 Opto-DO Card1
 * ap445_2 Opto-DO Card2
 * ap445_3 Opto-DO Card3
 *
 */

int apcard::open()
{
    optoDoCardHandle1 = 0;
    optoDoCardHandle2 = 0;
    optoDoCardHandle3 = 0;
    optoDoCardHandle4 = 0;

    optoDiCardHandle = 0;

    adcCardHandle1 = 0;
    adcCardHandle2 = 0;

#ifdef DEV_PC
    return (0);
#else
    int status = -1;

    status = initDo(); //AP445
    if(status != 0)
        return status;

    status = initDi(); //AP441
    if (status != 0)
        return status;

    status = initAdc(); //AP323
    if(status != 0)
        return status;

    qDebug() << "apcard: "<< "all AP Cards Opened";

    return (0);
#endif
}

void apcard::close()
{
    closeDo();
    closeDi();
    closeAdc();
    qDebug() << "apcard: "<< "all AP Cards Closed";
}

int apcard::initDi()
{
    memset(&c_block441_1, 0, sizeof(c_block441_1));
    memset(&s_block441_1, 0, sizeof(s_block441_1));

    c_block441_1.bAP = FALSE; // Indicate no AP initialized
    c_block441_1.bInitialized = FALSE; // Indicate not ready to talk to AP
    c_block441_1.sblk_ptr = (struct sblk441*)&s_block441_1; // Set address of status structure

    if (InitAPLib() != S_OK) {
        printf("\nUnable to initialize the AP library. Exiting program.\n");
        return (10); // UNABLE TO INITIALISE AP LIBRARY
    }

    if (APOpen(0, &optoDiCardHandle, DEVICE_NAME_OPTO_DI) != S_OK) {
        printf("\nUnable to Open instance of %s.\n", DEVICE_NAME_OPTO_DI);
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        c_block441_1.nHandle = optoDiCardHandle;
    }

    if (APInitialize(optoDiCardHandle) == S_OK)
    { // Initialize
        GetAPAddress(optoDiCardHandle, &baddr441_1); // Read back address
        c_block441_1.brd_ptr = (struct map441 *)baddr441_1;
        c_block441_1.bInitialized = TRUE;
        c_block441_1.bAP = TRUE; // Set AP initialized flag
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }
    return(0);
}

int apcard::readDi(int ch_no)
{
    long status;
    int port, point;
    short ret;

    ret = -1;

    port  = ch_no / 8;
    point = ch_no % 8;

    //Input port number   (0 - 3)
    //Input point number  (7 - 0)
    status = (long)rpnt441(&c_block441_1,(uint8_t)port, (uint8_t)point);

    if (status == -1)
    {
        return(97); //UNABLE TO READ DI
    }

    ret = (int)status;

    return ret;
}

void apcard::closeDi()
{
    BOOL cardFlag;

    cardFlag = c_block441_1.bAP;
    if (cardFlag)
    {
        APClose(optoDiCardHandle); // Close the AP instance
    }
}

int apcard::initDo()
{

    memset(&s_block445_1, 0, sizeof(s_block445_1));
    memset(&s_block445_2, 0, sizeof(s_block445_2));
    memset(&s_block445_3, 0, sizeof(s_block445_3));
    memset(&s_block445_4, 0, sizeof(s_block445_4));

    s_block445_1.bAP = false;          // indicate no carrier initialized and set up yet
    s_block445_1.bInitialized = false; // indicate not ready to talk to IP
    s_block445_1.nHandle = 0;          // make handle to a closed carrier board

    s_block445_2.bAP = false;          // indicate no carrier initialized and set up yet
    s_block445_2.bInitialized = false; // indicate not ready to talk to IP
    s_block445_2.nHandle = 0;          // make handle to a closed carrier board

    s_block445_3.bAP = false;          // indicate no carrier initialized and set up yet
    s_block445_3.bInitialized = false; // indicate not ready to talk to IP
    s_block445_3.nHandle = 0;          // make handle to a closed carrier board

    s_block445_4.bAP = false;          // indicate no carrier initialized and set up yet
    s_block445_4.bInitialized = false; // indicate not ready to talk to IP
    s_block445_4.nHandle = 0;          // make handle to a closed carrier board

    if (InitAPLib() != S_OK) {
        printf("\nUnable to initialize the AP library. Exiting program.\n");
        return (10); // UNABLE TO INITIALISE AP LIBRARY
    }

    if (APOpen(0, &optoDoCardHandle1, DEVICE_NAME_OPTO_DO) != S_OK) {
        printf("\nUnable to Open instance of %s.\n", DEVICE_NAME_OPTO_DO);
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        s_block445_1.nHandle = optoDoCardHandle1;
    }

    if (APInitialize(optoDoCardHandle1) == S_OK)
    { // Initialize
        GetAPAddress(optoDoCardHandle1, &baddr445_1); // Read back address
        s_block445_1.brd_ptr = (struct map445 *)baddr445_1;
        s_block445_1.bInitialized = TRUE;
        s_block445_1.bAP = TRUE; // Set AP initialized flag
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }

    if (APOpen(1, &optoDoCardHandle2, DEVICE_NAME_OPTO_DO) != S_OK) {
        printf("\nUnable to Open instance of %s.\n", DEVICE_NAME_OPTO_DO);
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        s_block445_2.nHandle = optoDoCardHandle2;
    }

    if (APInitialize(optoDoCardHandle2) == S_OK)
    { // Initialize
        GetAPAddress(optoDoCardHandle2, &baddr445_2); // Read back address
        s_block445_2.brd_ptr = (struct map445 *)baddr445_2;
        s_block445_2.bInitialized = TRUE;
        s_block445_2.bAP = TRUE; // Set AP initialized flag
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }

    if (APOpen(2, &optoDoCardHandle3, DEVICE_NAME_OPTO_DO) != S_OK) {
        printf("\nUnable to Open instance of %s.\n", DEVICE_NAME_OPTO_DO);
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        s_block445_3.nHandle = optoDoCardHandle3;
    }

    if (APInitialize(optoDoCardHandle3) == S_OK)
    { // Initialize
        GetAPAddress(optoDoCardHandle3, &baddr445_3); // Read back address
        s_block445_3.brd_ptr = (struct map445 *)baddr445_3;
        s_block445_3.bInitialized = TRUE;
        s_block445_3.bAP = TRUE; // Set AP initialized flag
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }

    if (APOpen(3, &optoDoCardHandle4, DEVICE_NAME_OPTO_DO) != S_OK) {
        printf("\nUnable to Open instance of %s.\n", DEVICE_NAME_OPTO_DO);
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        s_block445_4.nHandle = optoDoCardHandle4;
    }

    if (APInitialize(optoDoCardHandle4) == S_OK)
    { // Initialize
        GetAPAddress(optoDoCardHandle4, &baddr445_4); // Read back address
        s_block445_4.brd_ptr = (struct map445 *)baddr445_4;
        s_block445_4.bInitialized = TRUE;
        s_block445_4.bAP = TRUE; // Set AP initialized flag
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }

    return(0);
}

int apcard::writeDo_1(int ch_no, int on_off)
{
    long status;
    int  point;

    point = ch_no;
    status = wpnt445(&s_block445_1, point, on_off);
    if(status == -1 )
    {
        return(7); //UNABLE TO WRITE DO
    }
    return (0);
}
int apcard::writeDo_2(int ch_no, int on_off)
{
    long status;
    int  point;

    point = ch_no;
    status = wpnt445(&s_block445_2, point, on_off);
    if(status == -1 )
    {
        return(7); //UNABLE TO WRITE DO
    }
    return (0);
}
int apcard::writeDo_3(int ch_no, int on_off)
{
    long status;
    int  point;

    point = ch_no;
    status = wpnt445(&s_block445_3, point, on_off);
    if(status == -1 )
    {
        return(7); //UNABLE TO WRITE DO
    }
    return (0);
}
int apcard::writeDo_4(int ch_no, int on_off)
{
    long status;
    int  point;

    point = ch_no;
    status = wpnt445(&s_block445_4, point, on_off);
    if(status == -1 )
    {
        return(7); //UNABLE TO WRITE DO
    }
    return (0);
}

int apcard::readDo_1(int ch_no)
{
    long  status;
    int   point;
    short ret;

    ret = -1;
    point = ch_no;
    status = rpnt445(&s_block445_1, point);
    if(status == -1)
    {
        return(96); //UNABLE TO READ DO
    }
    ret = (int)status;
    return ret;
}
int apcard::readDo_2(int ch_no)
{
    long  status;
    int   point;
    short ret;

    ret = -1;
    point = ch_no;
    status = rpnt445(&s_block445_2, point);
    if(status == -1)
    {
        return(96); //UNABLE TO READ DO
    }
    ret = (int)status;
    return ret;
}
int apcard::readDo_3(int ch_no)
{
    long  status;
    int   point;
    short ret;

    ret = -1;
    point = ch_no;
    status = rpnt445(&s_block445_3, point);
    if(status == -1)
    {
        return(96); //UNABLE TO READ DO
    }
    ret = (int)status;
    return ret;
}
int apcard::readDo_4(int ch_no)
{
    long  status;
    int   point;
    short ret;

    ret = -1;
    point = ch_no;
    status = rpnt445(&s_block445_4, point);
    if(status == -1)
    {
        return(96); //UNABLE TO READ DO
    }
    ret = (int)status;
    return ret;
}

int apcard::writeOptoDo(int ch_no, int on_off)
{
    long status;
    int  point;

    point = ch_no;
    status = wpnt445(&s_block445_4, point, on_off);
    if(status == -1 )
    {
        return(7); //UNABLE TO WRITE DO
    }
    return (0);
}
int apcard::readOptoDoStatus(int ch_no)
{
    long  status;
    int   point;
    short ret;

    ret = -1;
    point = ch_no;
    status = rpnt445(&s_block445_4, point);
    if(status == -1)
    {
        return(96); //UNABLE TO READ DO
    }
    ret = (int)status;
    return ret;
}

void apcard::closeDo()
{
    BOOL cardFlag;

    cardFlag = s_block445_1.bAP;
    if (cardFlag)
    {
        APClose(optoDoCardHandle1); // Close the AP instance
    }

    cardFlag = s_block445_2.bAP;
    if (cardFlag)
    {
        APClose(optoDoCardHandle2); // Close the AP instance
    }

    cardFlag = s_block445_3.bAP;
    if (cardFlag)
    {
        APClose(optoDoCardHandle3); // Close the AP instance
    }

    cardFlag = s_block445_4.bAP;
    if (cardFlag)
    {
        APClose(optoDoCardHandle4); // Close the AP instance
    }
}

int apcard::initAdc()
{
    int j;                   /* loop index */

    memset(&c_block323_1, 0, sizeof(c_block323_1));	/* Initialize the Configuration Parameter Block */
    memset(s_array_1, 0, sizeof(s_array_1));        /* clear s_array */

    memset(cor_data_1, 0, sizeof(cor_data_1));	/* clear corrected sample buffer */
    memset(raw_data_1, 0, sizeof(raw_data_1));	/* clear raw sample buffer */

    memset(&c_block323_2, 0, sizeof(c_block323_2));	/* Initialize the Configuration Parameter Block */
    memset(s_array_2, 0, sizeof(s_array_2));        /* clear s_array */

    memset(cor_data_2, 0, sizeof(cor_data_2));	/* clear corrected sample buffer */
    memset(raw_data_2, 0, sizeof(raw_data_2));	/* clear raw sample buffer */

    for (j = 0; j < SA_CHANS; j++)
    {
        c_block323_1.s_cor_buf[j] = &cor_data_1[j][0];   /* corrected buffer start for each channel */
        c_block323_1.s_raw_buf[j] = &raw_data_1[j][0];   /* raw buffer start for each channel */

        c_block323_2.s_cor_buf[j] = &cor_data_2[j][0];   /* corrected buffer start for each channel */
        c_block323_2.s_raw_buf[j] = &raw_data_2[j][0];   /* raw buffer start for each channel */
    }

    //set config params

    c_block323_1.range        = RANGE_10TO10;	/* default +-10 to 10 V */
    c_block323_1.acq_mode     = DI_SELECT;		/* mode */
    c_block323_1.scan_mode    = UN_CONT;		/* scan mode */
    c_block323_1.data_format  = TC_SELECT;		/* A/D data format */
    c_block323_1.timer_ps     = 0xff;			/* prescaler */
    c_block323_1.conv_timer   = 0x55;           /* counter */
    c_block323_1.timer_en     = TIMER_ON;		/* timer on */
    c_block323_1.trigger      = TO_SELECT;		/* trigger I/O is output */
    c_block323_1.int_mode     = INT_DIS;		/* disable interrupt mode */
    c_block323_1.control      = 0;              /* control register used by read only*/
    c_block323_1.sa_start     = &s_array_1[0];	/* address of start of scan array */
    c_block323_1.sa_end       = &s_array_1[0];	/* address of end of scan array */
    c_block323_1.bAP          = FALSE;			/* indicate not initialized and set up yet */
    c_block323_1.bInitialized = FALSE;          /* indicate not ready */
    c_block323_1.nHandle      = 0;              /* make handle to a closed board */

    c_block323_2.range        = RANGE_10TO10;	/* default +-10 to 10 V */
    c_block323_2.acq_mode     = DI_SELECT;		/* mode */
    c_block323_2.scan_mode    = UN_CONT;		/* scan mode */
    c_block323_2.data_format  = TC_SELECT;		/* A/D data format */
    c_block323_2.timer_ps     = 0xff;			/* prescaler */
    c_block323_2.conv_timer   = 0x55;           /* counter */
    c_block323_2.timer_en     = TIMER_ON;		/* timer on */
    c_block323_2.trigger      = TO_SELECT;		/* trigger I/O is output */
    c_block323_2.int_mode     = INT_DIS;		/* disable interrupt mode */
    c_block323_2.control      = 0;              /* control register used by read only*/
    c_block323_2.sa_start     = &s_array_2[0];	/* address of start of scan array */
    c_block323_2.sa_end       = &s_array_2[0];	/* address of end of scan array */
    c_block323_2.bAP          = FALSE;			/* indicate not initialized and set up yet */
    c_block323_2.bInitialized = FALSE;          /* indicate not ready */
    c_block323_2.nHandle      = 0;              /* make handle to a closed board */

//    int elements = 1024;
    /*
     * Initialize the AP library
     */

    if (InitAPLib() != S_OK)
    {
        printf("\nUnable to initialize the AP library. Exiting program.\n");
        return (10); // UNABLE TO INITIALISE AP LIBRARY
    }

    /*
     * Open an instance of a AP device
     */

    if (APOpen(0, &adcCardHandle1, DEVICE_NAME_AI) != S_OK)
    {
        printf("\nUnable to Open instance of AP323.\n");
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        c_block323_1.nHandle = adcCardHandle1;
    }

    if (APInitialize(adcCardHandle1) == S_OK)/* Initialize */
    {
        GetAPAddress(adcCardHandle1, &baddr323_1);	/* Read back address */
        c_block323_1.brd_ptr = (struct map323 *)baddr323_1;
        c_block323_1.bInitialized = TRUE;
        c_block323_1.bAP = TRUE;
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }
    memset(&c_block323_1.IDbuf[0], 0, sizeof(c_block323_1.IDbuf));	/* empty the buffer */
    ReadFlashID323(&c_block323_1, &c_block323_1.IDbuf[0]);

    /* Install ideal values for each reference value */
    /* Reference Values 0=9.88V, 1=4.94V, 2=2.47V, and 3=1.235V */
    strcpy(&c_block323_1.RefCalValues[0][0], "9.88");
    strcpy(&c_block323_1.RefCalValues[1][0], "4.94");
    strcpy(&c_block323_1.RefCalValues[2][0], "2.47");
    strcpy(&c_block323_1.RefCalValues[3][0], "1.235");


    //qDebug() << "apcard: "<< "flash ID found";
    /* If the AP323 flash ID is found and confirmed */
    if ((strstr((const char *)&c_block323_1.IDbuf[0], (const char *)FlashIDString) == NULL))	/* AP323 ID */
    {
        //printf("\nUnable to read APBoard FLASH ID.\n");
        //APClose(c_block323_1.nHandle);
        return 97;
    }

    //qDebug() << "apcard: "<< "read the factory reference";
    /* Read the factory reference values from flash and overwrite the previously installed ideal values */
    if (ReadCalCoeffs323(&c_block323_1) != 0) /* read from flash into structure */
    {
        //printf("\nUnable to read calibration values from Flash memory.\n");
        //APClose(c_block323_1.nHandle);
        return 96;
    }

    usleep(2000);
    qDebug() << "apcard: "<< "get auto-zero values";
    calibrateAP323(&c_block323_1, AZ_SELECT);   /* get auto-zero values */
    usleep(2000);

    qDebug() << "apcard: "<< "get calibration values";
    calibrateAP323(&c_block323_1, CAL_SELECT);  /* get calibration values */
    usleep(2000);

    if (APOpen(1, &adcCardHandle2, DEVICE_NAME_AI) != S_OK)
    {
        printf("\nUnable to Open instance of AP323.\n");
        return(2); //UNABLE TO OPEN AP CARD
    }
    else
    {
        c_block323_2.nHandle = adcCardHandle2;
    }

    if (APInitialize(adcCardHandle2) == S_OK)/* Initialize */
    {
        GetAPAddress(adcCardHandle2, &baddr323_2);	/* Read back address */
        c_block323_2.brd_ptr = (struct map323 *)baddr323_2;
        c_block323_2.bInitialized = TRUE;
        c_block323_2.bAP = TRUE;
    }
    else
    {
        return (11);     // UNABLE TO INITIALISE AP ADDRESS
    }
    memset(&c_block323_2.IDbuf[0], 0, sizeof(c_block323_2.IDbuf));	/* empty the buffer */
    ReadFlashID323(&c_block323_2, &c_block323_2.IDbuf[0]);

    /* Install ideal values for each reference value */
    /* Reference Values 0=9.88V, 1=4.94V, 2=2.47V, and 3=1.235V */
    strcpy(&c_block323_2.RefCalValues[0][0], "9.88");
    strcpy(&c_block323_2.RefCalValues[1][0], "4.94");
    strcpy(&c_block323_2.RefCalValues[2][0], "2.47");
    strcpy(&c_block323_2.RefCalValues[3][0], "1.235");

    /* If the AP323 flash ID is found and confirmed */
    if ((strstr((const char *)&c_block323_2.IDbuf[0], (const char *)FlashIDString) == NULL))	/* AP323 ID */
    {
        printf("\nUnable to read APBoard FLASH ID.\n");
        //APClose(c_block323_2.nHandle);
        return 97;
    }

    /* Read the factory reference values from flash and overwrite the previously installed ideal values */
    if (ReadCalCoeffs323(&c_block323_2) != 0) /* read from flash into structure */
    {
        printf("\nUnable to read calibration values from Flash memory.\n");
        //APClose(c_block323_2.nHandle);
        return 96;
    }

    usleep(2000);
    calibrateAP323(&c_block323_2, AZ_SELECT);   /* get auto-zero values */
    usleep(2000);

    calibrateAP323(&c_block323_2, CAL_SELECT);  /* get calibration values */
    usleep(2000);

    return(0);
}

float apcard::readADC_A(int ch_no)
{
#ifdef DEV_PC
    float value = 0.0;

    return value;
#else
    int i, j;                   /* loop index */

    double span_val;                   /* span value */
    double zero_val;                   /* zero value */

    for (i = 0; i < SA_SIZE; i++)
    {
        *(c_block323_1.sa_start + i) = ch_no;
    }
    c_block323_1.sa_end = c_block323_1.sa_start + (SA_SIZE - 1);


    //qDebug() << "apcard: "<< "read auto zero, calibration data,";
    /* read auto zero, calibration data, raw data values and convert to voltage*/
    // if (!c_block323_1.bInitialized)
    // {
    //     //APClose(c_block323_1.nHandle);
    //     return 95;
    // }

    //qDebug() << "apcard: "<< "convert the board ";
    convertAP323(&c_block323_1);                /* convert the board */
    usleep(2000);

    //qDebug() << "apcard: "<< "correct input data";
    mccdAP323(&c_block323_1);       /* correct input data */
    usleep(2000);

    //channel &= 0x2f;     /* limit range */

    zero_val = -10.0000;        /* RANGE_10TO10 */
    span_val =  20.0000;

    // for (i = 0; i < SA_SIZE; i++)
    // {
    //     *(c_block323_1.sa_start + i) = ch_no;
    //     //printf("Channel assigned for Array Index %1X:%2X\n", i, *(c_block323.sa_start+i));
    // }

    //usleep(2000);

    //read values
    double sum = 0.0;

    // Read values and compute the average
    for (i = 0; i < SA_SIZE; i++)
    {
        //usleep(2000);
        double value = ((((double)c_block323_1.s_cor_buf[ch_no][i]) * span_val) / 65536.0) + zero_val;
        //printf("%12.6f ", value);
        sum += value;  // Accumulate the sum
    }

    double average = sum / SA_SIZE;
    //printf("\n Average Voltage reading: %12.6f\n", average);  // Print average

    //clear buffers
    memset(cor_data_1, 0, sizeof(cor_data_1));	/* clear corrected sample buffer */
    memset(raw_data_1, 0, sizeof(raw_data_1));	/* clear raw sample buffer */
    //usleep(2000);
    for (j = 0; j < SA_CHANS; j++)
    {
        c_block323_1.s_cor_buf[j] = &cor_data_1[j][0];   /* corrected buffer start for each channel */
        c_block323_1.s_raw_buf[j] = &raw_data_1[j][0];   /* raw buffer start for each channel */
    }
    return average;
#endif
}

float apcard::readADC_B(int ch_no)
{
#ifdef DEV_PC
    float value = 0.0;

    return value;
#else
    int i, j;                   /* loop index */

    double span_val;                   /* span value */
    double zero_val;                   /* zero value */

    for (i = 0; i < SA_SIZE; i++)
    {
        *(c_block323_2.sa_start + i) = ch_no;
    }
    c_block323_2.sa_end = c_block323_2.sa_start + (SA_SIZE - 1);


    // /* read auto zero, calibration data, raw data values and convert to voltage*/
    // if (!c_block323_2.bInitialized)
    // {
    //     //APClose(c_block323_2.nHandle);
    //     return 95;
    // }

    convertAP323(&c_block323_2);                /* convert the board */
    usleep(2000);

    mccdAP323(&c_block323_2);       /* correct input data */
    usleep(2000);

    //channel &= 0x2f;     /* limit range */

    zero_val = -10.0000;        /* RANGE_10TO10 */
    span_val =  20.0000;

    // for (i = 0; i < SA_SIZE; i++)
    // {
    //     *(c_block323_2.sa_start + i) = ch_no;
    //     //printf("Channel assigned for Array Index %1X:%2X\n", i, *(c_block323.sa_start+i));
    // }

    //usleep(2000);

    //read values
    double sum = 0.0;

    // Read values and compute the average
    for (i = 0; i < SA_SIZE; i++)
    {
        //usleep(2000);
        double value = ((((double)c_block323_2.s_cor_buf[ch_no][i]) * span_val) / 65536.0) + zero_val;
        //printf("%12.6f ", value);
        sum += value;  // Accumulate the sum
    }

    double average = sum / SA_SIZE;
    //printf("\n Average Voltage reading: %12.6f\n", average);  // Print average

    //clear buffers
    memset(cor_data_2, 0, sizeof(cor_data_2));	/* clear corrected sample buffer */
    memset(raw_data_2, 0, sizeof(raw_data_2));	/* clear raw sample buffer */

    for (j = 0; j < SA_CHANS; j++)
    {
        c_block323_2.s_cor_buf[j] = &cor_data_2[j][0];   /* corrected buffer start for each channel */
        c_block323_2.s_raw_buf[j] = &raw_data_2[j][0];   /* raw buffer start for each channel */
    }
    return average;
#endif
}
void apcard::closeAdc()
{
    BOOL cardFlag;

    cardFlag = c_block323_1.bAP;
    if (cardFlag)
    {
        APClose(adcCardHandle1); // Close the AP instance
    }

    cardFlag = c_block323_2.bAP;
    if (cardFlag)
    {
        APClose(adcCardHandle2); // Close the AP instance
    }
}

void apcard::displayIpErrorMessage(int error)
{
    QMessageBox msgBox;
    QPalette p;
    QString message;
    msgBox.setIcon(QMessageBox::Critical);
    msgBox.setWindowTitle("Akash Missile Checkout Software");
    p.setColor(QPalette::WindowText, QColor("Red"));
    msgBox.setPalette(p);
    switch(error)
    {
    case 2: message = "UNABLE TO INITIALISE CARRIER";break;
    case 3: message = "UNABLE TO OPEN IP445";break;
    case 4: message = "UNABLE TO WRITE OPTO-DO";break;
    case 5: message = "UNABLE TO OPEN IP440";break;
    case 6: message = "UNABLE TO OPEN IP470";break;
    case 7: message = "UNABLE TO WRITE DO";break;
    case 8: message = "UNABLE TO OPEN IP330";break;
    case 9: message = "UNABLE TO CONFIGURE ADC";break;
    case 10: message = "UNABLE TO INITIALISE CARRIER LIBRARY";break;
    case 11: message = "UNABLE TO INITIALISE CARRIER ADDRESS";break;
    case 98: message = "UNABLE TO READ OPTO-DO";break;
    case 97: message = "UNABLE TO READ DI";break;
    case 96: message = "UNABLE TO READ D0";break;
    case 95: message = "UNABLE TO READ ADC";break;
    default: message = "UNKNOWN ERROR OCCURED";break;
    }

    msgBox.setText(message);
    msgBox.setInformativeText("PROGRAM CAN'T PROCEED FURTHER PRESS OK TO QUIT THE PROGRAM");
    msgBox.show();
    msgBox.exec();
    exit(0);
}

int apcard::write_DO(int index, int on_off)
{
    long status = -1;
    int  card;
    int  ch_no;

    card  = index / 32;
    ch_no = index % 32;

    switch (card)
    {
    case 0:
        status = writeDo_1(ch_no, on_off);
        break;
    case 1:
        status = writeDo_2(ch_no, on_off);
        break;
    case 2:
        status = writeDo_3(ch_no, on_off);
        break;
    case 3:
        status = writeDo_4(ch_no, on_off);
        break;
    }
    return status;
}

float apcard::read_AI(int index)
{
    float value = 0.0;
    int ch_no;
    int card;

    card  = index / 32;
    ch_no = index % 32;

    switch (card)
    {
    case 0:
        value = readADC_A(ch_no);
        break;
    case 1:
        value = readADC_B(ch_no);
        break;
    }
    return value;
}
